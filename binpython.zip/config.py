#This is the official sample package installation template of BINPython
#AGPL-V3 By Edward Hsing (https://github.com/xingyujie)

#This script will be run when the package is installing

#Copyright and notice text (displayed during installation)
#Custom installation running code START
setwindowtitle("Welcome to BINPython!")
print("Welcome to BINPython!")





#Custom installation running code END